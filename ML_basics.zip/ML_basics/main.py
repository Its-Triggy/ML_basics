#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 19:12:04 2019

@author: Tristan Fogt
"""

###############################################################################
#------------------------------------SET UP-----------------------------------#
###############################################################################
import os
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import SGDClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
import random

###############################################################################
#----------------------------------FUNCTIONS----------------------------------#
###############################################################################

#train and evaluate an sgd classifier with training and testing data
def train_and_evaluate_sgd(X_train, y_train, X_test, y_test):
    #Create the classifier
    clf = SGDClassifier(loss='log', max_iter=10000)
    #Train the classifier on the training data
    clf = clf.fit(X_train, y_train)
    
    #Predict the outputs for the training data using the classifier
    y_train_pred = clf.predict(X_train)
    #Calculate the accuracy score and append it to the list
    acc_train_ = accuracy_score(y_train_pred, y_train)
    
    #Predict the outputs for the held-out data using the classifier
    y_test_pred = clf.predict(X_test)
    #Calculate the accuracy score and append it to the list
    acc_held_ = accuracy_score(y_test_pred, y_test)

    return (acc_train_, acc_held_)


#train and evaluate a decision tree classifier with training and testing data
def train_and_evaluate_decision_tree(X_train, y_train, X_test, y_test):
    #Create the classifier
    clf = DecisionTreeClassifier(criterion='entropy')
    #Train the classifier on the training data
    clf = clf.fit(X_train, y_train)
    
    #Predict the outputs for the training data using the classifier
    y_train_pred = clf.predict(X_train)
    #Calculate the accuracy score and append it to the list
    acc_train_ = accuracy_score(y_train_pred, y_train)
    
    #Predict the outputs for the held-out data using the classifier
    y_test_pred = clf.predict(X_test)
    #Calculate the accuracy score and append it to the list
    acc_held_ = accuracy_score(y_test_pred, y_test)

    return (acc_train_, acc_held_)


#train and evaluate a decision stump classifier with training and testing data
def train_and_evaluate_decision_stump(X_train, y_train, X_test, y_test):
    #Create the classifier
    clf = DecisionTreeClassifier(criterion='entropy', max_depth=4)
    #Train the classifier on the training data
    clf = clf.fit(X_train, y_train)
    
    #Predict the outputs for the training data using the classifier
    y_train_pred = clf.predict(X_train)
    #Calculate the accuracy score and append it to the list
    acc_train_ = accuracy_score(y_train_pred, y_train)
    
    #Predict the outputs for the held-out data using the classifier
    y_test_pred = clf.predict(X_test)
    #Calculate the accuracy score and append it to the list
    acc_held_ = accuracy_score(y_test_pred, y_test)

    return (acc_train_, acc_held_)


#train and evaluate an sgd classifier (with stump outputs as inputs)with training and testing data
def train_and_evaluate_sgd_with_stumps(X_train, y_train, X_test, y_test):
    
    #A list of 50 decision stump classifiers is created
    classifiers = create_stump_classifiers(X_train, y_train, quantity=50)
    
    #Create a new X matrix (Where the features are the outputs of the classifiers for each X[i])
    X_train_prime = create_X_prime(X_train, classifiers)
    X_test_prime = create_X_prime(X_test, classifiers)
    
    #Use these X_prime matrices as input for the SGD classifier
    return train_and_evaluate_sgd(X_train_prime, y_train, X_test_prime, y_test)
    

#Takes in an X matrix and a list of classifiers, and returns a new X which is 
#a concatination of the outputs of the classifiers
def create_X_prime(X, classifiers):
    #The new X is initiated as an empty list
    new_X = []
    
    #Each row in the X matrix is put through every clasifier.
    for row in X:
        #The outputs from each classifier are stored in this list
        new_row =[]
        for clf in classifiers:
            new_row.append(clf[0].predict([row[clf[1]]])[0])
        #The rows are then collected in the matrix new_X
        new_X.append(new_row)
    
    return np.array(new_X)

#This function creates and trains 50 decision stump classifiers, each of which 
#Only considers 1/2 of the total features
def create_stump_classifiers(X, y, quantity=50):
    #This function creates 50 classifiers. They will be stored in this list
    classifiers = []
    
    for i in range(quantity):
        #Half of the columns are randomly selected
        columns = random.sample(range(len(X[0])), int(len(X[0])/2))
        #These columns are extrated from the X matrix
        X_reduced = X[:, columns]
        
        #A classifier is trained with the new X matrix
        clf = DecisionTreeClassifier(criterion='entropy', max_depth=4)
        #The classifier, along with the corresponding columns, is appended
        classifiers.append((clf.fit(X_reduced, y), columns))
    
    #The list of classifiers is then returned
    return classifiers

#Returns the upper and lower confidence bound for a list of values
def confidence(lst):
    S = np.std(lst)
    n=float(len(lst))
    x_bar = np.mean(lst)
    t = 2.776 #This is the t value for 95% confidence at 5-1 = 4 DoF
    
    conf_lower = x_bar-t*S/n**0.5
    conf_upper = x_bar+t*S/n**0.5
    
    return(conf_lower, conf_upper)


#Plots the results of all of the models
def plot_results(plot_data):
    sgd_train_acc = plot_data[0] 
    sgd_train_std = plot_data[1]  
    sgd_heldout_acc = plot_data[2]  
    sgd_heldout_std = plot_data[3]  
    sgd_test_acc = plot_data[4]            
    dt_train_acc = plot_data[5]  
    dt_train_std = plot_data[6]  
    dt_heldout_acc = plot_data[7]  
    dt_heldout_std = plot_data[8]  
    dt_test_acc = plot_data[9] 
    dt4_train_acc = plot_data[10]  
    dt4_train_std = plot_data[11]  
    dt4_heldout_acc = plot_data[12]  
    dt4_heldout_std = plot_data[13]  
    dt4_test_acc = plot_data[14] 
    stumps_train_acc = plot_data[15]  
    stumps_train_std = plot_data[16]  
    stumps_heldout_acc = plot_data[17]  
    stumps_heldout_std = plot_data[18]  
    stumps_test_acc  = plot_data[19] 
                 
    train_x_pos = [0, 4, 8, 12]
    cv_x_pos = [1, 5, 9, 13]
    test_x_pos = [2, 6, 10, 14]
    ticks = cv_x_pos

    labels = ['sgd', 'dt', 'dt4', 'stumps (4 x 50)']

    train_accs = [sgd_train_acc, dt_train_acc, dt4_train_acc, stumps_train_acc]
    train_errors = [sgd_train_std, dt_train_std, dt4_train_std, stumps_train_std]

    cv_accs = [sgd_heldout_acc, dt_heldout_acc, dt4_heldout_acc, stumps_heldout_acc]
    cv_errors = [sgd_heldout_std, dt_heldout_std, dt4_heldout_std, stumps_heldout_std]

    test_accs = [sgd_test_acc, dt_test_acc, dt4_test_acc, stumps_test_acc]

    fig, ax = plt.subplots()
    ax.bar(train_x_pos, train_accs, yerr=train_errors, align='center', alpha=0.5, ecolor='black', capsize=10, label='train')
    ax.bar(cv_x_pos, cv_accs, yerr=cv_errors, align='center', alpha=0.5, ecolor='black', capsize=10, label='held-out')
    ax.bar(test_x_pos, test_accs, align='center', alpha=0.5, capsize=10, label='test')
    ax.set_ylabel('Accuracy')
    ax.set_xticks(ticks)
    ax.set_xticklabels(labels)
    ax.set_title('Models')
    ax.yaxis.grid(True)
    ax.legend()
    plt.tight_layout()
###############################################################################
#----------------------------------MAIN CODE----------------------------------#
###############################################################################

 #We will execute our analysis on all four of these models
functions = [(train_and_evaluate_sgd, "SGD"),
             (train_and_evaluate_decision_tree, "Decision Tree"),
             (train_and_evaluate_decision_stump, "Decision Stump"),
             (train_and_evaluate_sgd_with_stumps, "SGD with Stumps")]   

#There's a bunch of data that needs to be plotted at the end. We will store 
#that data here as it is created, since the variables will constantly be 
#over-written in the loop.
plot_data = []

#We will perform the same analysis on all of our models    
for function in functions:   
    #These lists will store the two accuracies for each partitioning
    acc_train = []
    acc_held = []
    
    #Loop through all 5 partitions
    for i in range(5):
        #Load the appropriate files for the partition
        cv_train_X = np.load('hw1-materials/madelon/cv-train-X.'+str(i)+'.npy')
        cv_train_y = np.load('hw1-materials/madelon/cv-train-y.'+str(i)+'.npy')
        cv_held_X = np.load('hw1-materials/madelon/cv-heldout-X.'+str(i)+'.npy')
        cv_held_y = np.load('hw1-materials/madelon/cv-heldout-y.'+str(i)+'.npy')
        
        (acc_train_, acc_held_) = function[0](cv_train_X, cv_train_y, cv_held_X, cv_held_y)
        #(acc_train_, acc_held_) = function[0](cv_train_X[0:100], cv_train_y[0:100], cv_held_X[0:100], cv_held_y[0:100])

        acc_train.append(acc_train_)
        acc_held.append(acc_held_)
        
        conf_train_lower, conf_train_upper = confidence(acc_train)
        conf_held_lower, conf_held_upper = confidence(acc_held)
        
    plot_data.append(np.mean(acc_train))
    plot_data.append(np.std(acc_train))
    plot_data.append(np.mean(acc_held))
    plot_data.append(np.std(acc_held))
        
    print(function[1]+":")
    print("Average training accuracy: {0}\n95% confidence({1}, {2})".format(round(np.mean(acc_train),3), round(conf_train_lower,3), round(conf_train_upper,3)))
    print("\nAverage testing accuracy: {0}\n95% confidence({1}, {2})".format(round(np.mean(acc_held),3), round(conf_held_lower,3), round(conf_held_upper,3)))
    
    #Load the full data sets 
    X_train = np.load('hw1-materials/madelon/train-X.npy')
    y_train = np.load('hw1-materials/madelon/train-y.npy')
    X_test = np.load('hw1-materials/madelon/test-X.npy')
    y_test = np.load('hw1-materials/madelon/test-y.npy')    
        
    (final_acc_train, final_acc_test) = function[0](X_train, y_train, X_test, y_test)
    #(final_acc_train, final_acc_test) = function[0](X_train[0:100], y_train[0:100], X_test[0:100], y_test[0:100])
    
    plot_data.append(final_acc_test)
    print("\nFinal test accuracy: {0}".format(round(final_acc_test,3)))
    
    print("------------------------------------------")

    
if len(plot_data) != 20:
    print("ERROR! PANIC!")
    
plot_results(plot_data)

